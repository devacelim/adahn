
library(glmnet)


library(dprep) # for sonar data
data(sonar) # V61 = 1 : "R", V61 = 2 : "M"
set.seed(1)
train_ind = sample(1:nrow(sonar), size = floor(nrow(sonar)*0.7))
train.sonar = sonar[train_ind,]
test.sonar = sonar[-train_ind,]

train.sonar$V61 = ifelse(train.sonar$V61 == 1,"R","M")
test.sonar$V61 = ifelse(test.sonar$V61 == 1,"R","M") 

train.sonar$V61 = as.factor(train.sonar$V61)
test.sonar$V61 = as.factor(test.sonar$V61)


y = rep(1,nrow(train.sonar))
y[which(train.sonar$V61=="R")]=0
x = as.matrix(train.sonar[,-61])

cv.out = cv.glmnet(x,y,family="binomial",alpha=1)
lam =cv.out$lambda.min
fit.lasso = glmnet(x,y,family="binomial",alpha=1,lambda=lam)


newx = as.matrix(test.sonar[,-61])
pred_lasso = predict(fit.lasso,newx,type="class",s=lam)
plot(pred_lasso)

table(obs = test.sonar$V61,pred= ifelse(pred_lasso ==1,"M","R"))

1- sum(ifelse(ifelse(pred_lasso==1,"R","M")==test.sonar$V61,1,0)) /nrow(test.sonar) 