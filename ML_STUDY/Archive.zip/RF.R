

library(dprep) # for sonar data
data(sonar) # V61 = 1 : "R", V61 = 2 : "M"
set.seed(1)
train_ind = sample(1:nrow(sonar), size = floor(nrow(sonar)*0.7))
train.sonar = sonar[train_ind,]
test.sonar = sonar[-train_ind,]

train.sonar$V61 = ifelse(train.sonar$V61 == 1,"R","M")
test.sonar$V61 = ifelse(test.sonar$V61 == 1,"R","M") 

train.sonar$V61 = as.factor(train.sonar$V61)
test.sonar$V61 = as.factor(test.sonar$V61)
rf_train = randomForest(V61 ~., data = train.sonar,mtry=8,importance=T)

rf_train

rf_pred = predict(rf_train, newdata = test.sonar)
table(rf_pred,test.sonar$V61)

importance(rf_train)
varImpPlot(rf_train)

err_rate = matrix(0, nrow = 1, ncol = 1)
rownames(err_rate) = c("RF (m=8)")
colnames(err_rate) = c("test err")

rf_pred1 = predict(rf_train, newdata = test.sonar, type = "response")
err_rate[1,1] = length(which(rf_pred1 != test.sonar$V61))/nrow(test.sonar) 

err_rate
