library("e1071")

library(dprep) # for sonar data
data(sonar) # V61 = 1 : "R", V61 = 2 : "M"
set.seed(1)
train_ind = sample(1:nrow(sonar), size = floor(nrow(sonar)*0.7))
train.sonar = sonar[train_ind,]
test.sonar = sonar[-train_ind,]

train.sonar$V61 = ifelse(train.sonar$V61 == 1,"R","M")
test.sonar$V61 = ifelse(test.sonar$V61 == 1,"R","M") 

train.sonar$V61 = as.factor(train.sonar$V61)
test.sonar$V61 = as.factor(test.sonar$V61)


fit.svm = svm(V61~., data = train.sonar)
fit.svm
summary(fit.svm)

pred.svm = predict(fit.svm,test.sonar)

pred.svm
table(obs = test.sonar$V61,pred=pred.svm)
length(which(pred.svm != test.sonar$V61))/nrow(test.sonar) 