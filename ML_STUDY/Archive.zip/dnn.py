from __future__ import print_function
import numpy as np
import pandas
from keras.utils import np_utils
import os
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation
from keras.optimizers import SGD,adam


os.chdir('/Users/adahn/Downloads/SK_ML실습/')

df = pandas.read_table('train_sonar.txt', sep=' ')
X_train = np.array(df.drop('V61', axis=1).values)
y_train = df['V61'].astype('category')
Y_train = np_utils.to_categorical(y_train.cat.rename_categories([0,1]), 2).astype(np.int16)
df = pandas.read_table('test_sonar.txt', sep=' ')
X_test = np.array(df.drop('V61', axis=1).values)
y_test = df['V61'].astype('category')
Y_test = np_utils.to_categorical(y_test.cat.rename_categories([0,1]), 2).astype(np.int16)
print(X_train.shape[0], 'train samples')
print('X_train shape:', X_train.shape)
print('Y_train shape:', Y_train.shape)
print('Convert category ',y_train.cat.categories, 'to ', np.unique(Y_train))
print(X_test.shape[0], 'test samples')
print('X_test shape:', X_test.shape)
print('Y_test shape:', Y_test.shape)
print('Convert category ',y_test.cat.categories, 'to ', np.unique(Y_test))

batch_size=10
nb_epoch=100



nodes=10


model1 = Sequential()
model1.add(Dense(60, init='uniform', input_shape=(60,)))
model1.add(Activation('relu'))

model1.add(Dense(nodes, init='uniform' ))
model1.add(Activation('relu'))

model1.add(Dense(nodes, init='uniform' ))
model1.add(Activation('relu'))


model1.add(Dense(2, activation='softmax'))


model1.compile(loss='mse', optimizer='adam', metrics=['accuracy'])

model1.fit(X_train,Y_train,batch_size=batch_size,nb_epoch=nb_epoch,validation_data=(X_test,Y_test))

score1 = model1.evaluate(X_test, Y_test, verbose=0)



nodes=20


model2 = Sequential()
model2.add(Dense(60, init='uniform', input_shape=(60,)))
model2.add(Activation('relu'))

model2.add(Dense(nodes, init='uniform' ))
model2.add(Activation('relu'))

model2.add(Dense(nodes, init='uniform' ))
model2.add(Activation('relu'))


model2.add(Dense(2, activation='softmax'))


model2.compile(loss='mse', optimizer='adam', metrics=['accuracy'])

model2.fit(X_train,Y_train,batch_size=batch_size,nb_epoch=nb_epoch,validation_data=(X_test,Y_test))

score2 = model2.evaluate(X_test, Y_test, verbose=0)



print('\nModel1\n')
print('Test score:', score1[0])
print('Test accuracy:', score1[1])



print('\nModel2\n')
print('Test score:', score2[0])
print('Test accuracy:', score2[1])
