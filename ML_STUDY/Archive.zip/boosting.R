library(gbm)

library(dprep) # for sonar data
data(sonar) # V61 = 1 : "R", V61 = 2 : "M"
set.seed(1)
train_ind = sample(1:nrow(sonar), size = floor(nrow(sonar)*0.7))
train.sonar = sonar[train_ind,]
test.sonar = sonar[-train_ind,]

train.sonar$V61 = ifelse(train.sonar$V61 == 1,"R","M")
test.sonar$V61 = ifelse(test.sonar$V61 == 1,"R","M") 

train.sonar$V61 = as.factor(train.sonar$V61)
test.sonar$V61 = as.factor(test.sonar$V61)


gbm.fit = gbm(V61~., data=train.sonar,n.trees=10000, interaction.depth=1,shrinkage=0.01,distribution="gaussian",cv.folds=10)
relative.influence(gbm.fit)
plot(gbm.fit,i.var=2)
best.iter = gbm.perf(gbm.fit,method="cv")
pred.gbm = predict(gbm.fit,newdata = test.sonar,n.trees=best.iter,type='response')
pred.gbm
table(obs = test.sonar$V61,pred= ifelse(pred.gbm > 0.5,1,0))
1- sum(ifelse(ifelse(pred.gbm>0.5,1,0)==test.sonar$V61,1,0))
