setwd("C:/Users/Kimsarah/Desktop/sk_new")
###---- 1. 고차원 회귀모형
#Linear Regression
heat_cost = c(250, 360, 165, 43, 92, 200, 355, 290, 230, 120, 73, 205, 400, 320, 72, 272, 94, 190, 235, 139)
temper = c(35, 29, 36, 60, 65, 30, 10, 7, 21, 55, 54, 48, 20, 39, 60, 20, 58, 40, 27, 30)
insulation = c(3, 4, 7, 6, 5, 5, 6, 10, 9, 2, 12, 5, 5, 4, 8, 5, 7, 8, 9, 7)
furnace = c(6, 10, 3, 9, 6, 5, 7, 10, 11, 5, 4, 1, 15, 7, 6, 8, 3, 11, 8, 5)
house = data.frame(heat_cost, temper, insulation, furnace)

head(house)

mul_reg = lm(heat_cost ~. , data=  house)    #. : 나머지 모든 변수를 사용한다
summary(mul_reg)                             #각 변수에 붙은 별표 : 가설 검정과 관련
plot(mul_reg)                                #기본적인 가정 확인 가능

#variable selection
toyota.data = read.table("ToyotaCorolla.csv", header = T, sep = ",")
head(toyota.data)
summary(toyota.data$Fuel_Type)

Fuel_CNG = ifelse(toyota.data$Fuel_Type == "CNG", 1, 0)
Fuel_Diesel = ifelse(toyota.data$Fuel_Type == "Diesel", 1, 0)
selected.data = cbind(toyota.data[c(3, 4, 7)] , Fuel_CNG, Fuel_Diesel,
                      toyota.data[c(9, 10, 12, 13, 17, 18)])
head(selected.data , 4)
dim(selected.data)
set.seed(2)                                                           #Random 이 들어가도 같은 결과가 나올 수 있도록! (재현가능)
seed <- sample(1:nrow(selected.data), nrow(selected.data)/10)         #5대신 10으로 바꿔주세요!
train = as.matrix(selected.data[-seed,]) ; test = as.matrix(selected.data[seed,])

install.packages("leaps")
library(leaps)
vselect.fit_cp = leaps(x=train[,-1],y=train[,1],method="Cp", nbest=1) #method 를 통해 어떤것을 기준으로 삼을지 정할 수 있다. adjR2, R2도 가능
vselect.fit_cp

d=which.min(vselect.fit_cp$Cp)                                        #Cp는 작을수록 좋은 모형이다.
vselect.fit_cp$which[d,]                                              #첫번째 변수는 상수항
colnames(train)[-c(7,9)]

#forward & backward
train = as.data.frame(train)                                            #회귀분석을 위해 data frame 형태로 바꿔야..
null = lm(Price~1, data = train); full = lm(Price~., data = train)
forward = step(null, scope = list(lower = null, upper = full), data = train, direction = "forward")
forward$coefficients

backward = step(full, data = train, direction = "backward")
backward$coefficients

selected.fit = lm(Price~., data=as.data.frame(train)[,-c(7,9)])

#Penalized method
train=as.matrix(train)                                                #glmnet 함수 input으로는 matrix를 넣어야..

install.packages("glmnet")
library(glmnet)

ridge.fit = glmnet(train[,-1], train[,1], alpha=0)                    #lambda를 선택하지 않았을 때의 결과..
ridge.fit$beta
plot(ridge.fit)

cv.out = cv.glmnet(train[,-1], train[,1], alpha=0)                    #alpha = 0 : Ridge ; alpha = 1 : LASSO. 자동으로 standardize해서 계수 계산
bestlam = cv.out$lambda.min
ridge.fit = glmnet(train[,-1], train[,1], alpha=0, lambda=bestlam)

cv.out = cv.glmnet(train[,-1], train[,1], alpha=1)
bestlam = cv.out$lambda.min
lasso.fit = glmnet(train[,-1], train[,1], alpha=1, lambda=bestlam)

origin.fit = lm(Price~., data=as.data.frame(train))

selected.beta = rep(0,10)
selected.beta[-c(6,8)] = selected.fit$coefficient[-1]
beta = round(cbind(ridge.fit$beta, lasso.fit$beta,  origin.fit$coefficients[-1], selected.beta),4)
colnames(beta) = c("ridge", "lasso", "origin", "selection")
beta                                                                  #대체로 origin보다 0에 가까운 값을 갖는 것을 확인 가능

#test set에서의 squared error 비교
mean( (predict(ridge.fit, train[,-1])-train[,1])^2 )
mean( (predict(lasso.fit, train[,-1])-train[,1])^2 )
mean( (predict(origin.fit, as.data.frame(train) )-train[,1])^2 )
mean( (predict(selected.fit, as.data.frame(train) )-train[,1])^2 )

#test set에서의 squared error 비교
mean( (predict(ridge.fit, test[,-1])-test[,1])^2 )
mean( (predict(lasso.fit, test[,-1])-test[,1])^2 )
mean( (predict(origin.fit, as.data.frame(test) )-test[,1])^2 )
mean( (predict(selected.fit, as.data.frame(test) )-test[,1])^2 )
#ridge가 가장 좋음. 보통 ridge나 lasso 중 하나가 가장 좋음.  data의 속성에 따라 다


#Boston housing
library(MASS)
data(Boston)
head(Boston)


#Classification
mydata = read.csv("FlightDelays.csv")
str(mydata)                                                     #자료를 전체적으로 확인 가능
mydata$Weather = as.factor(mydata$Weather)
mydata$DAY_WEEK = as.factor(mydata$DAY_WEEK)
mydata$DEP_TIME = as.factor(floor(mydata$DEP_TIME/100))         #출발시각 중 시간만 살림
mydata=mydata[,c(2,3,4,5,8,9,10,13)]
summary(mydata)

set.seed(2)
train = sample(1:nrow(mydata), 1500)
mydata.test = mydata[-train,]
Flight.Status.test = mydata.test$Flight.Status

mydata.logistic = glm(Flight.Status ~. , data = mydata[train,], family=binomial)
mydata.logistic$coefficients                                    #factor의 경우, 각 항목 별로 계수가 생김 

mydata.predicted = predict(mydata.logistic, newdata=mydata.test, type="response")
mydata.classified = list()
fairloss = list()
for(i in 1:9){
  mydata.classified[[i]] = ifelse(mydata.predicted > i/10, "ontime", "delayed")
  fairloss[[i]] = ifelse(mydata.classified[[i]] == mydata.test$Flight.Status, 0, 1)
  print( paste("c = 0.",i," ", round(sum(fairloss[[i]])/( nrow(mydata)-length(train) ) , 4) )  )
}                                                               #항상 0.5를 기준으로 삼는게 좋은게 아니다. 

  
x=model.matrix(Flight.Status~., data=mydata[train,])            #LASSO도 가능 -> 대신 가변수를 생성해 주어야 한다. column수 확인
cv.out = cv.glmnet( x, mydata[train,8], alpha=1, family="binomial")
bestlam = cv.out$lambda.min
mydata.glmnet = glmnet( x, mydata[train,8], alpha=1, family="binomial", lambda=bestlam)

y=model.matrix(Flight.Status~., data=mydata[-train,])
mydata.predicted = predict(mydata.glmnet, newx=y, type="response")
mydata.classified = list()
fairloss = list()
for(i in 1:10){
  mydata.classified[[i]] = ifelse(mydata.predicted > i/10, "ontime", "delayed")
  fairloss[[i]] = ifelse(mydata.classified[[i]] == mydata.test$Flight.Status, 0, 1)
  print( paste("c = 0.",i," ", round(sum(fairloss[[i]])/( nrow(mydata)-length(train) ) , 4) )  )
}                                                               
mydata.glmnet$beta                                              #sparse한 해를 얻는 것을 확인할 수 있다.

############################
############################
###                      ###
###    Nonparametric     ###
###                      ###
############################



install.packages("leaps")
install.packages("glmnet")
install.packages("ISLR")
install.packages("gam")
install.packages("earth")
install.packages("tree")
install.packages("ElemStatLearn")
install.packages("klaR")
install.packages("randomForest")
install.packages("gbm")

###---- 2. 비모수 회귀모형

library(ISLR) # for data
data(Wage)
dim(Wage)
summary(Wage)
Wage[1,]
hist(Wage$wage, breaks=100, col = "steelblue",border = "darkgrey",
     main = "Histogram of wage") 
plot(Wage$age, Wage$wage, type="p", cex = 1, col ="darkgrey", pch = 19)


hist(Wage$logwage, breaks=100, col = "steelblue",border = "darkgrey",
     main = "Histogram of log(wage)") 
plot(Wage$logwage, Wage$wage, type="p", cex = 1, col ="darkgrey", pch = 19)

#---- smoothing spline

attach(Wage)
# smoothing spline using CV
fit1 = smooth.spline(age, wage, cv =T)
print(fit1)

# smoothing spline using the desired equivalent number of df
fit2 = smooth.spline(age, wage, df = 16)
print(fit2)

plot(age, wage, type="p", cex = 1, col ="darkgrey", pch = 19)
title("Smoothing Spline")
lines(fit1, col="coral", lwd = 4)
lines(fit2, col="steelblue", lwd = 4)
legend("topright", legend = c("6.8 DF", "16 DF"), col = c("coral", "steelblue"),
       lty = 1, lwd = 2, cex = 0.8)


#---- Generalized additive model
library(gam) 

# model : wage = f1(year) + f2(age) + education
gam1 <- gam(logwage ~ s(year, 4) + s(age, 5) + education, data = Wage)
gam1
summary(gam1)

par(mfrow=c(1,3))
plot(gam1, se = T, col="steelblue", lwd = 3)

# residuals plot
par(mfrow=c(1,3))
plot(fitted(gam1), residuals(gam1), pch =19, col ="darkgrey")
plot(year, residuals(gam1), pch =19,  col ="darkgrey")
plot(age, residuals(gam1), pch =19, col ="darkgrey")

anova(gam1)
# model2 : wage = f1(year) + f2(age) + education
# not defined df
gam2 <- gam(logwage ~ s(year) + s(age) + education, data = Wage)
gam2
anova(gam2)

gam3 = gam(logwage ~ s(age, 5)+education, data = Wage)
gam4 = gam(logwage ~ year + s(age, 5)+education, data = Wage)
anova(gam3, gam4, gam1, test ="F")

# model : wage = f1(year) + f2(age) + education
gam1 <- gam(wage ~ s(year, 4) + s(age, 5) + education, data = Wage)
gam1
summary(gam1)

# plot gam
par(mfrow = c(1,3))
plot(gam1, se = T, col="steelblue", lwd = 3)

# residuals plot
plot(fitted(gam1), residuals(gam1), pch =19, col ="darkgrey")
plot(year, residuals(gam1), pch =19,  col ="darkgrey")
plot(age, residuals(gam1), pch =19, col ="darkgrey")

anova(gam1)

# beta_hat : coef & vcov
b = coef(gam1) # estimated coefficients
V = vcov(gam1) # Bayesian cov matrix
b[1:4] #first 4 coefs
V[1:4, 1:4]

#---- PPR (project pursuit regression)

ppr0 = ppr(logwage~year+age+education, data = Wage[1:2000,], sm.method = 'spline',
            ,nterm = 3 )
summary(ppr0)

par(mfrow=c(1,3))
plot(ppr0)

# residuals plot
par(mfrow=c(1,3))
plot(fitted(ppr0), residuals(ppr0), pch =19, col ="darkgrey")
plot(year, residuals(ppr0), pch =19,  col ="darkgrey")
plot(age, residuals(ppr0), pch =19, col ="darkgrey")

## MARS (Multivariate Adaptive Regression Spline)
library(earth)
mars0 = earth(wage ~year+education+age , data = Wage, degree = 2)
plotmo(mars0)
summary(mars0)


# residuals plot
par(mfrow=c(1,3))
plot(fitted(mars0), residuals(mars0), pch =19, col ="darkgrey")
plot(year, residuals(mars0), pch =19,  col ="darkgrey")
plot(age, residuals(mars0), pch =19, col ="darkgrey")

#---- MARS (Multivariate Adaptive Regression Splines)

library(earth)
mars0 = earth(logwage ~year+age+education , data = Wage, degree = 2)
summary(mars0)

plotmo(mars0) #Plot a model's response over a range of predictor values

plot(mars0)

#---- 모형의 비교

set.seed(123)
train_ind = sample(1:nrow(Wage), size = 2000)
train = Wage[train_ind,-c(3,7,12)] #sex, region 제외
test = Wage[-train_ind,-c(3,7,12)]

MSE = matrix(0, nrow = 3, ncol = 2)
rownames(MSE) = c("GAM","PPR","MARS")
colnames(MSE) = c("train err","test err")

# gam

predictors = names(train)[-9]
pred_conti = predictors[c(1,2)]
pred_fact = predictors[-c(1,2)]
candidates <- function(pred) {
  return(paste("s(",pred,")",sep=""))
}

s.formula = candidates(pred_conti)
lin.fla1 = paste(s.formula,collapse=" + ")
lin.fla2 = paste(pred_fact, collapse="+")
lin.fla = paste("logwage ~ ",lin.fla1,"+",lin.fla2,sep="")
lin.fla = formula(lin.fla)

gam_train = gam(lin.fla, data = train, family = gaussian)

gam_pred1 = predict(gam_train, newdata = train, type="response")
MSE[1,1] = mean(sum((train$logwage-gam_pred1)^2))
gam_pred2 = predict(gam_train, newdata = test, type="response")
MSE[1,2] = mean(sum((test$logwage-gam_pred2)^2))

par(mfrow =c(1,2))
plot(train$logwage, gam_pred1, col="darkgrey", cex=0.7,pch=19,main="GAM train")
abline(0,1,col="red", lwd =2)
plot(test$logwage, gam_pred2, col="darkgrey", cex=0.7,pch=19,main="GAM test")
abline(0,1,col="red", lwd =2)

# ppr
ppr_train = ppr(logwage~., data = train, nterm = 10)

ppr_pred1 = predict(ppr_train, newdata = train, type = "response")
MSE[2,1] = mean(sum((train$logwage-ppr_pred1)^2))
ppr_pred2 = predict(ppr_train, newdata = test, type = "response")
MSE[2,2] = mean(sum((test$logwage-ppr_pred2)^2))

par(mfrow =c(1,2))
plot(train$logwage, ppr_pred1, col="darkgrey", cex=0.7,pch=19,main="PPR train")
abline(0,1,col="red", lwd =2)
plot(test$logwage, ppr_pred2, col="darkgrey", cex=0.7,pch=19,main="PPR test")
abline(0,1,col="red", lwd =2)

# mars
mars_train = earth(logwage~., data = train, degree = 2)

mars_pred1 = predict(mars_train, newdata = train, type = "response")
MSE[3,1] = mean(sum((train$logwage-mars_pred1)^2))
mars_pred2 = predict(mars_train, newdata = test, type = "response")
MSE[3,2] = mean(sum((test$logwage-mars_pred2)^2))

par(mfrow =c(1,2))
plot(train$logwage, mars_pred1, col="darkgrey", cex=0.7,pch=19,main="MARS train")
abline(0,1,col="red", lwd =2)
plot(test$logwage, mars_pred2, col="darkgrey", cex=0.7,pch=19,main="MARS test")
abline(0,1,col="red", lwd =2)

MSE
summary(mars_train)
plot(mars_train)
plotmo(mars_train)


#----- non-parametric regression : classification

#---- Naive Bayes classifier
library(ElemStatLearn)
data(spam, package="ElemStatLearn")

library(klaR)

# training data
set.seed(123)
train_ind = sample(1:nrow(spam), size = 3000)
train_spam = spam[train_ind,]
test_spam = spam[-train_ind,]

nb_train = NaiveBayes(spam ~ ., data = train_spam)

# visualizes the marginal prob. of predictor variables given the class
par(mfrow=c(2,4))
plot(nb_train)

#---- 모형 비교
err = matrix(0, nrow = 4, ncol = 2)
rownames(err) = c("NB","GAM","PPR","MARS")
colnames(err) = c("train err","test err")

# NB

nb_pred1 = predict(nb_train, newdata = train_spam)
err[1,1] = length(which(train_spam$spam != nb_pred1$class))/nrow(train_spam)

nb_pred2 = predict(nb_train, newdata = test_spam)
err[1,2] = length(which(test_spam$spam != nb_pred2$class))/nrow(test_spam)

# GAM

train_spam[,58] = ifelse(train_spam[,58] == "spam",1,0)
test_spam[,58] = ifelse(test_spam[,58] == "spam",1,0)

predictors = names(train_spam)[-58]
candidates <- function(pred) {
  return(paste("s(",pred,")",sep=""))
}
s.formula = candidates(predictors)
lin.fla = paste(s.formula,collapse=" + ")
lin.fla = paste("spam ~ ",lin.fla,sep="")
lin.fla = formula(lin.fla)

gam_train = gam(lin.fla, data = train_spam, family = binomial(link = "logit"))

gam_pred1 = round(predict(gam_train, newdata = train_spam, type="response"))
err[2,1] = length(which(gam_pred1 != train_spam[,58]))/nrow(train_spam)
gam_pred2 = round(predict(gam_train, newdata = test_spam, type="response"))
err[2,2] = length(which(gam_pred2 != test_spam[,58]))/nrow(test_spam)

# PPR

ppr_train = ppr(spam~., data = train_spam, nterm = 2)

ppr_pred1 = round(predict(ppr_train, newdata = train_spam, type = "response"))
err[3,1] = length(which(ppr_pred1 != train_spam[,58]))/nrow(train_spam)
ppr_pred2 = round(predict(ppr_train, newdata = test_spam, type = "response"))
err[3,2] = length(which(ppr_pred2 != test_spam[,58]))/nrow(test_spam)

# MARS

mars_train = earth(spam~., data = train_spam, degree = 2)

mars_pred1 = round(predict(mars_train, newdata = train_spam, type = "response"))
err[4,1] = length(which(mars_pred1 != train_spam[,58]))/nrow(train_spam)
mars_pred2 = round(predict(mars_train, newdata = test_spam, type = "response"))
err[4,2] = length(which(mars_pred2 != test_spam[,58]))/nrow(test_spam)

err

###---- 3. 의사결정나무 및 앙상블

#----- Decision tree

library(tree)
tree.mydata = tree(Flight.Status~., data=mydata)
summary(tree.mydata)

par(pin = c(4, 3))
plot(tree.mydata)
text(tree.mydata, pretty=0)

# 학습자료와 시험자료로 나누어서 모형의 성능 확인 

set.seed(2)
train = sample(1:nrow(mydata), 1500)
mydata.test = mydata[-train,]
Flight.Status.test = mydata.test$Flight.Status
tree.mydata = tree(Flight.Status~., mydata[train,])
tree.pred = predict ( tree.mydata, mydata.test, type = "class")
table(tree.pred, Flight.Status.test)
1 - sum(diag(table(tree.pred, Flight.Status.test)))/ length(tree.pred)    



#----- Bagging & Random forest
data(spam, package="ElemStatLearn")

# training data
set.seed(123)
train_ind = sample(1:nrow(spam), size = 3000)
train_spam = spam[train_ind,]
test_spam = spam[-train_ind,]

library(randomForest)

# use the spam data
set.seed(1)
rf_train = randomForest(spam ~., data = train_spam, ntree = 500
                        , mtry = 8, importance = T)
rf_train 
importance(rf_train)
varImpPlot(rf_train)

err_rate = matrix(0, nrow = 2, ncol = 2)
rownames(err_rate) = c("RF (m=8)","Bagging")
colnames(err_rate) = c("train err","test err")

rf_pred1 = predict(rf_train, newdata = train_spam, type = "response")
err_rate[1,1] = length(which(rf_pred1 != train_spam[,58]))/nrow(train_spam) 
rf_pred2 = predict(rf_train, newdata = test_spam, type = "response")
err_rate[1,2] = length(which(rf_pred2 != test_spam[,58]))/nrow(test_spam) 


## Bagging
set.seed(1)
bag_train = randomForest(spam ~., data = train_spam, mtry = 57, importance = T)
bag_train 
importance(bag_train)
varImpPlot(bag_train)

bag_pred1 = predict(bag_train, newdata = train_spam, type = "response")
err_rate[2,1] = length(which(bag_pred1 != train_spam[,58]))/nrow(train_spam)
bag_pred2 = predict(bag_train, newdata = test_spam, type = "response")
err_rate[2,2] = length(which(bag_pred2 != test_spam[,58]))/nrow(test_spam)

err_rate

# partial dependence plot

par(mfrow =c(1,2))
partialPlot(bag_train, train_spam, A.21, "spam")
partialPlot(rf_train, train_spam, A.21, "spam")


#---- Boosting

mydata$Flight.Status = as.integer(mydata$Flight.Status) -1      

library(gbm)
set.seed(4)
gbm.fit = gbm(Flight.Status~., data=mydata[train,], n.trees=10000,
              interaction.depth = 1, shrinkage=0.01, bag.fraction=1)

# 어떤 변수들을 이용해서 모형이 구축되었는지 확인 

relative.influence(gbm.fit)

plot(gbm.fit,i.var=2)


# 오분류율 계산 

errrate=c()
for(i in seq(1000,10000,length.out=10)){
  pred = predict(gbm.fit, mydata.test,i)
  pred = pred >0
  pred_table <- data.frame(True = mydata.test$Flight.Status, pred)
  errrate=c(errrate,1 - round(sum(diag(table(pred_table))) /701 , 4) )
}
names(errrate) = seq(1000,10000,length.out=10)

errrate
